/*
 * Description: 
 *     History: yang@haipo.me, 2017/03/17, create
 */

# ifndef _ME_CLI_H_
# define _ME_CLI_H_

int init_cli(void);

# endif

