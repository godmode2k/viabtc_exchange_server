/*
 * Description: 
 *     History: yang@haipo.me, 2017/04/18, create
 */

# ifndef _MP_SERVER_H_
# define _MP_SERVER_H_

int init_server(void);

# endif

