/*
 * Description: 
 *     History: yang@haipo.me, 2016/04/19, create
 */

# ifndef _AC_SERVER_H_
# define _AC_SERVER_H_

int init_server(void);

# endif

