/*
 * Description: 
 *     History: yang@haipo.me, 2017/03/16, create
 */

# ifndef _ME_SERVER_H_
# define _ME_SERVER_H_

int init_server(void);

# endif

